#include <iostream>
#include <cmath>
#include "vector.hpp"

//Constructor personalizado
Vector::Vector(int n){
  n_elems = n;
  data = new double[n_elems];
}

//Constructor copia
Vector::Vector(const Vector &obj){
  n_elems = obj.n_elems;
  data = new double[n_elems];
  for(int i = 0; i < obj.n_elems; ++i){
    data[i] = obj.data[i];
  }
}

//Operador asignación
Vector &Vector::operator=(const Vector &obj){
  if (n_elems!=obj.n_elems){
    throw "Operador asignacion: Error, los vectores tienen dimensionalidad distinta";
  }
  n_elems = obj.n_elems;
  for (int i = 0; i < n_elems; i++) {
    data[i] = obj.data[i];
  }
  return *this;
}

//Destructor
Vector::~Vector(){
  delete [] data;
}

//Impresion
void Vector::print(){
  std::cout << "[" ;
  for (int i = 0; i < n_elems; i++) {
    if (i != n_elems-1){
      std::cout << data[i] << ", " ;
    }
    else {
      std::cout << data[i] << "]\n" ;
    }
  }
}

//Obtener el numero de elementos
int Vector::obtener_n_elems(){
  return n_elems;
}

//Operador +
Vector Vector::operator+(const Vector &obj){
  if (n_elems!=obj.n_elems){
    throw "Operador +: Error, los vectores tienen dimensionalidad distinta";
  }
  Vector temp(n_elems);
  for (int i = 0; i < n_elems; i++) {
    temp.data[i] = data[i] + obj.data[i];
  }
  return temp;
}

//Operador -
Vector Vector::operator-(const Vector &obj){
  if (n_elems!=obj.n_elems){
    throw "Operador -: Error, los vectores tienen dimensionalidad distinta";
  }
  Vector temp(n_elems);
  for (int i = 0; i < n_elems; i++) {
    temp.data[i] = data[i] - obj.data[i];
  }
  return temp;
}

//Operador * (producto escalar)
double Vector::operator*(const Vector &obj){
  if (n_elems!=obj.n_elems){
    throw "Operador *: Error, los vectores tienen dimensionalidad distinta";
  }
  double suma = 0;
  for (int i = 0; i < n_elems; i++) {
    suma += data[i]*obj.data[i];
  }
  return suma;
}

//Operador <<
std::ostream& operator<<(std::ostream& os, const Vector &obj){
  os << "[" ;
  for (int i = 0; i < obj.n_elems; i++) {
    if (i != obj.n_elems-1){
       os << obj.data[i] << ", " ;
    }
    else {
      os << obj.data[i] << "]" ;
    }
  }
  return os;
}

