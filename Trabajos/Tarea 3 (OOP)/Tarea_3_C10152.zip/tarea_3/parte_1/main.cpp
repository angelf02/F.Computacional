#include <iostream>
#include "vector.hpp"

int main(){
        std::cout << "Bienvenido a una implementacion de OOP dirigida a trabajar con vectores. Primero se inicializaran tres vectores:" << std::endl;

        Vector A(4);
        for (int i = 0; i < A.obtener_n_elems(); ++i){
                A.data[i] = i;
        }
        std::cout << "A = " << A << ". Cuyo numero de elementos es: " << A.obtener_n_elems() << std::endl;

        Vector B = A;
        B.data[0] = -50;
        B.data[B.obtener_n_elems()-1] = 10;
        std::cout << "B es una copia de A, pero su primer y ultima entrada fueron cambiadas, de manera que B = " << B << ". Por lo tanto, el numero de elementos en B es: " << B.obtener_n_elems() << std::endl;

        Vector C(6);
        for (int i = 0; i < C.obtener_n_elems(); ++i){
                C.data[i] = i;
        }
        std::cout << "Finalmente, el numero de elementos en C es: " << C.obtener_n_elems() << ". Y sus entradas son: "<< "C = ";
        C.print();

        //Vector D;
        //A.n_elems = 2;

        std::cout << "\nYa que la dimensionalidad de A es la misma que la de B ( " << A.obtener_n_elems() << " = " << B.obtener_n_elems() << " ), entonces se tiene: \nM = A+B = ";
        try{
                Vector M = A+B;
                M.print();
        }
        catch(const char* msg){
                std::cerr << msg << std::endl;
        }
        try{
                Vector N = A-B;
                std::cout << "N = A-B =" << N << std::endl;
        }
        catch(const char* msg){
                std::cerr << msg << std::endl;
        }
        try{
                double x = A*B;
                std::cout << "El producto punto entre A y B es: x = A*B = " << x << std::endl;
        }
        catch(const char* msg){
                std::cerr << msg << std::endl;
        }
        try{
                B = A;
                std::cout << "Si se reemplaza los elementos de B con los de A: B = A = " << B << std::endl;
        }
        catch(const char* msg){
                std::cerr << msg << std::endl;
        }

        std::cout << "\nPero, si se intenta realizar estas operaciones con vectores de distintas dimensiones (como el caso de A y C): " << std::endl;
        try{
                Vector O = A+C;
        }
        catch(const char* msg){
                std::cerr << msg << std::endl;
        }
        try{
                Vector P = A-C;
        }
        catch(const char* msg){
                std::cerr << msg << std::endl;
        }
        try{
                double Q = A*C;
        }
        catch(const char* msg){
                std::cerr << msg << std::endl;
        }
        try{
                C = A;
        }
        catch(const char* msg){
                std::cerr << msg << std::endl;
        }

        return 0;
}

