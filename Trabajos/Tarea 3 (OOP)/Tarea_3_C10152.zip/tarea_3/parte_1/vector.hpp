#ifndef VECTOR_HPP
#define VECTOR_HPP

class Vector
{
  public:
    double *data;
    int obtener_n_elems();
    Vector(int n); //Constructor personalizado
    Vector(const Vector &obj); //Constructor copia
    Vector &operator=(const Vector &obj); //Operador asignacion
    ~Vector(); //Destructor
    void print();
    Vector operator+(const Vector &obj);
    Vector operator-(const Vector &obj);
    double operator*(const Vector &obj);
    friend std::ostream& operator<<(std::ostream &os, const Vector &obj);
  private:
    int n_elems;
    Vector();
};

#endif

