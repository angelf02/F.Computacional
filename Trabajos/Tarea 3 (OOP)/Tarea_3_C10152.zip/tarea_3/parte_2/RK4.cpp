#include <iostream>
#include <cmath>
#include <vector>
#include <fstream>

double dyn_generator(double indep, double dep){
	return 2*(1-dep) - std::exp(-4*indep);
}

double rk4(double (*func)(double, double), double indep, double dep, double h){
	double k1 = h*func(indep,dep);
	double k2 = h*func(indep+h/2,dep+k1/2);
	double k3 = h*func(indep+h/2,dep+k2/2);
	double k4 = h*func(indep+h,dep+k3);
	return dep + (1.0/6.0)*(k1+2*k2+2*k3+k4);
}	


int main(){
	double dep_n = 1.0; //Estado inicial.
	
	std::vector<double> indep_puntos;
	double indep_inicio = 0.0;
	double indep_fin = 2.0;
	int indep_num = 5;
	double step = (indep_fin - indep_inicio) / (indep_num - 1);
	for (int i = 0; i < indep_num; ++i) {
		indep_puntos.push_back(indep_inicio + (i * step));	
	}

	double h = indep_puntos[1] - indep_puntos[0];

  std::ofstream outputFile("./output.txt");
  for (int i = 0; i < indep_puntos.size(); ++i){
		outputFile << indep_puntos[i] << " " << dep_n << std::endl;
   	dep_n = rk4(dyn_generator, indep_puntos[i], dep_n, h);
	}
  outputFile.close();
  std::cout << "Los puntos obtenidos fueron almacenados en ./output.txt" << std::endl;
 
	return  0;
}

